from django.apps import AppConfig


class BookshopConfig(AppConfig):
    name = 'bookshop'
